"""
Platform Algorithm API
"""
