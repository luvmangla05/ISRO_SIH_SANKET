# Problem Statement 4

## Title of Problem Statement

Development of an AI-Based Virtual Camera Tracking System for Coarse Alignment of Mobile Free Space Optical Communication (FSOC) Terminals

## Description (Background, Detailed Description and Expected Solution):

### Background:

Free Space Optical Communication (FSOC) offers unprecedented advantages for next-generation mobile networks, including gigabit-to-terabit data rates, license-free spectrum operation, high immunity to electromagnetic interference, etc. However, deploying FSOC links between mobile platforms satellites, UAVs presents a severe challenge of pointing, acquisition and tracking (PAT) of highly narrow laser beams. PAT typically happens in two stages: coarse alignment and fine alignment. Coarse alignment is one of the key challenges of PAT, where the transmitting terminal must first locate and maintain the remote terminal within its camera Field-of-View (FOV).

Developing and testing such algorithms on real hardware requires expensive cameras, pan-tilt mechanisms, and optical components & equipment. A software based virtual camera tracking provides an inexpensive and accessible platform for algorithm development and learning.

### Description:

Unlike conventional radio-frequency systems, FSOC relies on a highly directional optical beam. Even a small angular error can prevent successful communication. Before fine pointing mechanism can take over, a coarse alignment stage must:

- Observe the surrounding environment,
- Acquire and detect the remote terminal or beacon,
- Estimate the position, and
- Continuously adjust the pointing direction to maintain visibility.

The participants shall develop this coarse alignment process in software, allowing to develop and validate tracking algorithms without specialized hardware and setup. The following section provides reference parameters and performance criteria to be considered for the software development.

### Parameters and Specifications:

**Functional Objective:** Develop a software system that autonomously detects, identifies, and continuously tracks a designated moving target within a virtual scene by controlling a virtual camera viewport.

| Sr. No. | Parameter | Suggested Value | Remarks |
|---|---|---|---|
| | **Camera Parameters** | | |
| 1. | Screen Size (min.) | 2000 x 2000 pixels | Optional: User-defined |
| 2. | Camera Type | Monochrome, Focal Plane Array | Optional: Colour |
| 3. | Camera Resolution | 640 x 480 pixels | Optional: User-defined |
| 4. | Camera FOV | User-defined | Default: 4° x 3° |
| 5. | Camera update Rate | 30 Hz (min.) | |
| 6. | Initial Camera Position | Centre of the Screen | |
| | **Target Parameters** | | |
| 7. | Target Type | Beacon Spot | |
| 8. | Number of Targets | 1, mandatory | multiple optional |
| 9. | Target Shape | User-defined | Default: Square |
| 10. | Target Size | 5-20 x 5-20 pixels (user-defined) | Default: 10 x 10 |
| 11. | Initial Target Location | User-defined | Default: Random |
| 12. | Motion | Selectable, at least four: Straight Line,<br>Circular, Figure of 8, Random | Optional:<br>Spiral, Sinusoidal, User-defined |
| | **Camera Motion Constraints** | | |
| 13. | Max. Pan Speed | 5-10 °/s (User-defined) | Default: 5 °/s |
| 14. | Max. Tilt Speed | 5-10 °/s (User-defined) | Default: 5 °/s |
| 15. | Update Interval | ≥ 20 Hz | |
| | **Performance Specifications** | | |
| 16. | Acquisition Time | ≤ 2 sec | |
| 17. | Tracking Error | ≤ 10 pixels | |
| 18. | Target Loss | < 5% | |
| 19. | Re-acquisition Time | ≤ 1 sec | |
| 20. | Processing Speed | ≥ 20 FPS | |
| | **Disturbances and Noise** | | |
| 21. | Image Noise | 1. Salt & Pepper (around 10% of image), 2. Gaussian & 3. Poisson | User Selectable (one or more) |
| 2. | Max. Standard Deviation of Noise | 20 pixels | User-defined |
| 3. | Max. Camera Jitter | ± 20 pixels / frame | User-defined |
| 4. | Atmospheric Disturbance | Clear, Haze, Fog, Rain, Low light | User-defined reduction in<br>contrast and brightness |
| 5. | Platform Motion | ± 20 pixels/frame (max.) | User selectable<br>Default/Mandatory: Linear<br>Optional: Circular, random,<br>spiral, figure of 8, etc. |

### Key Milestones:

### Expected Solution:

Participants shall develop an AI-assisted camera tracking system capable of automatically detecting and continuously tracking a moving optical beacon in a simulated video stream while controlling a virtual pan-tilt camera.

The developed software shall be able to:

- Generate a configurable virtual environment,
- Generate one or more moving targets,
- Implement a movable virtual camera,
- Detect the target beacon automatically,
- Track the beacon continuously using computer vision,
- Control and reposition the virtual camera,
- Generate and introduce disturbances due to atmospheric turbulence, platform vibrations, camera motion, noise, etc., in the virtual camera feed,
- Display tracking performance and statistics in real-time

### Deliverables

Each participating team shall submit the following mandatory deliverables:

#### Software Application

A standalone executable application implementing the complete virtual camera tracking system. The application shall provide all the mandatory functions and features as described above.

#### Source Code

Complete source code with proper documentation. The code shall be modular and adequately commented.

#### Technical Report

The technical report (about 10-15 pages) containing problem understanding, system architecture, description of software modules, tracking methods, AI methods (if used), test methodology, performance analysis and future improvements shall be submitted.

#### User Manual

The user manual with the description of installation of software, application operation, parameter configuration, GUI description, etc. shall be submitted. A 3–5 minutes video may also be provided as an optional deliverable for demonstration of the application.

#### Performance Log

The software should be capable of automatically generating a performance report containing simulation duration, FPS, acquisition time, average and maximum tracking error, lock retention rate, processing time, etc.

### Evaluation Method and Criteria

The solutions developed by participating teams will be evaluated using multi-layered evaluation method. The following table describes stages of evaluation, their weightage and methods.

| Evaluation Stage | Description | Evaluation Method and Criteria | Marks (%) |
|---|---|---|---|
| **Functional Verification** | Teams are given 10-15 minutes to demonstrate the software and its functionality. | 1. Implementation of all mandatory functions<br>2. Operational success<br>3. GUI | 20 |
| **Benchmark Performance-1** | Each team will be given few scenarios. | 1. Execution of the scenario<br>2. Log of Centroiding error<br>3. Automatically generated performance logs | 30 |
| **Benchmark Performance-2** | Each team will be given a few video files (.mp4) @30 fps, covering a complete screen with noise and moving beacon spot. The software needs to bypass its PTZ camera and take this video as an input to the coarse pointing system. | 1. Comparison of Centroiding error with predefined error values<br>2. Performance w.r.t. various parameters like RMSE, acquisition and re-acquisition time, Lock retention rate, FPS, etc. | 30 |
| **Technical Evaluation** | Teams present their approach, methods, architecture, design, etc to the evaluators. | 1. Understanding of the problem<br>2. System architecture and software design<br>3. Selection of Algorithms<br>4. AI and computer vision<br>5. Innovation and Novelty<br>6. Technical Documentation and Presentation<br>7. Technical Discussion and Q&A | 20 |

**Organization (Ministry/Department Name):** Department of Space / Indian Space Research Organisation  
**Category (Hardware/Software):** Software  
**Theme (Available at www.sih.gov.in):** Smart Automation, Space Technology  
**Youtube Link/Video Link:** NA  
**Dataset Link (real-data or dummy data):** NA
